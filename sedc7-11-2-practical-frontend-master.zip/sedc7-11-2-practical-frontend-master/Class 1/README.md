# Class 01

Hey guys!
Welcome to the first class of this elective subject.

[This](https://docs.google.com/document/d/1zO5IF_Tjk9fuVk2rRqr-TKunwRE8VqJzCxfYtldGzGo/edit?usp=sharing) is what we learned so far from November to December in the previous subject called Basic Web Development.

[Following this link](https://docs.google.com/document/d/1fma2sHr1yTB5X9AW9s3XXe53EL0oNBs_gv4ryOz0Lic/edit?usp=sharing) you can have a sneak peak of the program, divided for each class, where you can see everyhing that we will learn this 10 classes.

You can find all of the needed images for the first exercise in the folter of this class's repo, the font needed for this exercise is *Lato*, you can easily find it and include it in the html file by using Google Fonts. The images for the first exercise are hero.jpg and logo.png, and the layout you need to code is called exercise-01.png. The other files and images are for the second part od the exercise with is not mandatory, you can make that section after the first exercise, if you have some time left.

Please try to do this exercise on your own and don't be afraid to ask me for any guidance if needed.

For any questions, please send me an email. 
You can add the homework to git and send me a link or send me the code as a zip to the following email.

# Email: jovana.siskovska@yahoo.com
