# Class 5

[Please follow this link](https://www.w3schools.com/css/css_pseudo_classes.asp) for more info about pseudo selectors. If you have any questions about them, we can discuss them next class.
