# Class 6

- [JQuery Version](https://code.jquery.com/)
- [Owl Carousel Download](https://owlcarousel2.github.io/OwlCarousel2/)
- [GitHub Pages Tutorial Link](https://help.github.com/en/articles/configuring-a-publishing-source-for-github-pages)

> When uploading the site, make sure that you are uploading all files directly to the branch, don't put them in a folder. The index.html file should not be in a folder, in order for GitHub to know which is the main HTML file.
