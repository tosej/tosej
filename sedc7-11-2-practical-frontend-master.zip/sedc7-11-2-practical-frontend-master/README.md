# sedc7-11-2-practical-frontend
Source code repository for SEDC Code Academy 7.0 elective subject 'Practical Frontend' students exercises.
